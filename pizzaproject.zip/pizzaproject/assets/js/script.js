var dataObj = [
    {
        "itemId": "001",
        "itemCategory":"buy1get1",
        "itemImg":"combo1.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"575"
    },
    {
        "itemId": "002",
        "itemCategory":"buy1get1",
        "itemImg":"combo2.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"veg",
        "itemPrice":"675"
    },
    {
        "itemId": "003",
        "itemCategory":"buy1get1",
        "itemImg":"combo3.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"875"
    },
    {
        "itemId": "004",
        "itemCategory":"buy1get1",
        "itemImg":"combo3.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"veg",
        "itemPrice":"499"
    },
    {
        "itemId": "005",
        "itemCategory":"sidesbeverages",
        "itemImg":"Beverages1.jpg",
        "itemTitle":"Coke",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"499"
    },
    {
        "itemId": "006",
        "itemCategory":"sidesbeverages",
        "itemImg":"Beverages2.jpg",
        "itemTitle":"Ice Tea",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"499"
    },
    {
        "itemId": "007",
        "itemCategory":"sidesbeverages",
        "itemImg":"Beverages3.jpg",
        "itemTitle":"Lemonade",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"veg",
        "itemPrice":"499"
    },
    {
        "itemId": "008",
        "itemCategory":"sidesbeverages",
        "itemImg":"Beverages4.jpg",
        "itemTitle":"Sauces",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"875"
    },
    {
        "itemId": "009",
        "itemCategory":"desserts25savings",
        "itemImg":"Desserts1.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"599"
    },
    {
        "itemId": "010",
        "itemCategory":"desserts25savings",
        "itemImg":"Desserts2.jpg",
        "itemTitle":"Red Velvet Pastry",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"veg",
        "itemPrice":"599"
    },
    {
        "itemId": "011",
        "itemCategory":"desserts25savings",
        "itemImg":"Desserts3.jpg",
        "itemTitle":"Choca Pastry",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"599"
    },
    {
        "itemId": "012",
        "itemCategory":"desserts25savings",
        "itemImg":"Desserts4.jpg",
        "itemTitle":"Chocolate Cake",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"veg",
        "itemPrice":"599"
    },
    {
        "itemId": "013",
        "itemCategory":"personalhalfpizzas",
        "itemImg":"1.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"veg",
        "itemPrice":"599"
    },
    {
        "itemId": "014",
        "itemCategory":"personalhalfpizzas",
        "itemImg":"2.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"799"
    },
    {
        "itemId": "015",
        "itemCategory":"personalhalfpizzas",
        "itemImg":"3.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"veg",
        "itemPrice":"799"
    },
    {
        "itemId": "016",
        "itemCategory":"personalhalfpizzas",
        "itemImg":"4.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"799"
    },
    {
        "itemId": "017",
        "itemCategory":"personalhalfpizzas",
        "itemImg":"5.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"veg",
        "itemPrice":"799"
    },
    {
        "itemId": "018",
        "itemCategory":"personalhalfpizzas",
        "itemImg":"6.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"799"
    },
    {
        "itemId": "019",
        "itemCategory":"personalhalfpizzas",
        "itemImg":"7.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"veg",
        "itemPrice":"999"
    },        
    {
        "itemId": "020",
        "itemCategory":"personalhalfpizzas",
        "itemImg":"8.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"999"
    },
    {
        "itemId": "021",
        "itemCategory":"cheeseburstpizzas",
        "itemImg":"9.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"999"
    },
    {
        "itemId": "022",
        "itemCategory":"cheeseburstpizzas",
        "itemImg":"10.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"veg",
        "itemPrice":"999"
    },
    {
        "itemId": "023",
        "itemCategory":"cheeseburstpizzas",
        "itemImg":"11.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"veg",
        "itemPrice":"999"
    },
    {
        "itemId": "024",
        "itemCategory":"cheeseburstpizzas",
        "itemImg":"12.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"veg",
        "itemPrice":"999"
    },
    {
        "itemId": "025",
        "itemCategory":"desserts",
        "itemImg":"Desserts1.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"449"
    },
    {
        "itemId": "026",
        "itemCategory":"desserts",
        "itemImg":"Desserts2.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"449"
    },    
    {
        "itemId": "027",
        "itemCategory":"desserts",
        "itemImg":"Desserts3.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"449"
    },    
    {
        "itemId": "028",
        "itemCategory":"desserts",
        "itemImg":"Desserts4.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"veg",
        "itemPrice":"449"
    },    
    {
        "itemId": "029",
        "itemCategory":"signaturepizzas",
        "itemImg":"11.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"veg",
        "itemPrice":"449"
    },    
    {
        "itemId": "030",
        "itemCategory":"signaturepizzas",
        "itemImg":"12.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"299"
    },    
    {
        "itemId": "031",
        "itemCategory":"signaturepizzas",
        "itemImg":"13.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"veg",
        "itemPrice":"299"
    },    
    {
        "itemId": "032",
        "itemCategory":"signaturepizzas",
        "itemImg":"14.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"299"
    },    
    {
        "itemId": "033",
        "itemCategory":"halfandhalfpizzas",
        "itemImg":"combo1.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"veg",
        "itemPrice":"299"
    },    
    {
        "itemId": "034",
        "itemCategory":"halfandhalfpizzas",
        "itemImg":"combo2.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"299"
    },    
    {
        "itemId": "035",
        "itemCategory":"halfandhalfpizzas",
        "itemImg":"combo3.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"399"
    },    
    {
        "itemId": "036",
        "itemCategory":"halfandhalfpizzas",
        "itemImg":"combo4.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"399"
    },    
    {
        "itemId": "037",
        "itemCategory":"pastasandlasagne",
        "itemImg":"pasta1.png",
        "itemTitle":"Pasta",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"veg",
        "itemPrice":"399"
    },    
    {
        "itemId": "038",
        "itemCategory":"pastasandlasagne",
        "itemImg":"pasta2.png",
        "itemTitle":"Pasta",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"veg",
        "itemPrice":"399"
    },    
    {
        "itemId": "039",
        "itemCategory":"pastasandlasagne",
        "itemImg":"pasta3.png",
        "itemTitle":"Pasta",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"399"
    },    
    {
        "itemId": "040",
        "itemCategory":"pastasandlasagne",
        "itemImg":"pasta4.png",
        "itemTitle":"Pasta",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"399"
    },
    {
        "itemId": "041",
        "itemCategory":"buyonegetone",
        "itemImg":"combo1.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"veg",
        "itemPrice":"399"
    },    
    {
        "itemId": "042",
        "itemCategory":"buyonegetone",
        "itemImg":"combo2.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"399"
    },    
    {
        "itemId": "043",
        "itemCategory":"buyonegetone",
        "itemImg":"combo3.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"veg",
        "itemPrice":"399"
    },    
    {
        "itemId": "044",
        "itemCategory":"buyonegetone",
        "itemImg":"combo4.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"399"
    },    
    {
        "itemId": "045",
        "itemCategory":"combos4",
        "itemImg":"9.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"veg",
        "itemPrice":"599"
    },    
    {
        "itemId": "046",
        "itemCategory":"combos4",
        "itemImg":"10.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"599"
    },    
    {
        "itemId": "047",
        "itemCategory":"combos4",
        "itemImg":"11.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"veg",
        "itemPrice":"599"
    },    
    {
        "itemId": "048",
        "itemCategory":"combos4",
        "itemImg":"12.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"599"
    },    
    {
        "itemId": "049",
        "itemCategory":"combos2",
        "itemImg":"1.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"veg",
        "itemPrice":"599"
    },    
    {
        "itemId": "050",
        "itemCategory":"combos2",
        "itemImg":"2.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"1199"
    },    
    {
        "itemId": "051",
        "itemCategory":"combos2",
        "itemImg":"3.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"1199"
    },    
    {
        "itemId": "052",
        "itemCategory":"combos2",
        "itemImg":"4.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"veg",
        "itemPrice":"1199"
    },    
    {
        "itemId": "053",
        "itemCategory":"pizzaparty",
        "itemImg":"13.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"nonVeg",
        "itemPrice":"1199"
    },    
    {
        "itemId": "054",
        "itemCategory":"pizzaparty",
        "itemImg":"14.jpg",
        "itemTitle":"Choose any 2 Non-Veg Pizzas.",
        "itemDesc":"Conubia primis per fames scelerisque tellus scelerisque hac sagittis hendrerit ac parturient ut a in at praesent aliquet sed.",
        "itemType":"veg",
        "itemPrice":"1199"
    }
];

$(".owl-carousel").owlCarousel({
    loop: true,
    margin: 10,
    nav: true,
    autoplay: true,
    responsive: {
      0: {
        items: 2,
      },
      600: {
        items: 3,
      },
      1000: {
        items: 4,
      },
    },
});

$(document).on("click",".sidebarList .listItem",function(){
    var category = $(this).data("id");
    $(".sidebarList .listItem.active").removeClass("active");
    $(this).addClass("active");
    if( $(window).width() > 767 ) {
        $('html, body').animate({
            scrollTop: $('#'+category).offset().top-82
        }, 1000);  
    } else {
        $('html, body').animate({
            scrollTop: $('#'+category).offset().top-188
        }, 1000);
    }
});

$(window).scroll(function() {
    var position = $(this).scrollTop();
    $(".category").each(function(){
        var target = $(this).offset().top;
        var id = $(this).attr('id');
        if (position >= (target-110)) {
            $(".sidebarList .listItem.active").removeClass("active");
            $('.sidebarList .listItem[data-id="'+id+'"]').addClass("active");
        }
    });    
});

$("#switchVeg").click(function(){
    if($(this).hasClass("active")){
        $(".foodIndicator.nonVeg").closest(".item").css("display","flex");
        $(this).removeClass("active");
    }else{
        $(".foodIndicator.nonVeg").closest(".item").css("display","none");
        $(this).addClass("active");
    }
});

var categoryHeadings = $(".category>h2");
$("#itemSearch").on("keyup", function() {
    $("#overlay").show();
    var g = $(this).val().toLowerCase();
    $(".itemTitle").each(function() {
        var s = $(this).text().toLowerCase();
        $(this).closest('.item')[ s.indexOf(g) !== -1 ? 'show' : 'hide' ]();
    });
    if(g){
        $(categoryHeadings).hide();
    }else{
        $(categoryHeadings).show();
    }
    $('html, body').animate({
        scrollTop: $(".mainContainer").offset().top-70
    }, 100);
    $("#overlay").hide();
});

var cartItems = localStorage.getItem("pizzaCartItems") ? JSON.parse(localStorage.getItem("pizzaCartItems")) : [];

function addToCart(item){
    dataObj.find(x => {
        if(x.itemId === item){
            if($("#cart-"+x.itemId).length > 0){
                $("#cart-"+x.itemId).find(".qtyInc").trigger("click");
            }else{
                $("#cartItems").append(`
                    <div class="cartItem" id="cart-${x.itemId}">
                        <div class="cartItemTitle">${x.itemTitle}</div>
                        <div class="cartItemType"><span class="foodIndicator ${x.itemType}">•</span></div>
                        <div class="cartItemQtyDiv"><span class="qtyDec">-</span><span class="cartItemQty">1</span><span class="qtyInc">+</span></div>
                        <div class="cartItemPrice">₹${x.itemPrice}</div>
                    </div>
                `);
                cartItems.push(item);
                localStorage.setItem("pizzaCartItems", JSON.stringify(cartItems));
            }
        }
    });
}

function checkCart() {
    if($(".cartItem").length == 0){
        $("#cartWrapper").html(`
            <h2>Cart</h2>
            <div id="cartItems"></div>
            <div class="payAmount">
                <div>Pay Amount</div>
                <div>₹<span id="totalAmount"></span></div>
            </div>
            <div class="checkoutWrapper"><a href="javascript:void(0);">Checkout</a></div>
        `);
    }    
}

function clearCart() {
    $("#cartWrapper").html(`
        <h2>Cart Empty</h2>
        <img src="./assets/images/empty-cart.png" alt="Empty Cart" title="Empty Cart"/>
        <h5>Empty Cart</h5>
        <p>Let your Standout experience begin!</p>
    `);
}

function calcTotal(){
    let cartTotal = 0;
    $(cartItems).each(function(key,value){
        dataObj.find(elm => {
            if(elm.itemId === value){
                // let qty = parseInt($("#cart-"+elm.itemId).find(".cartItemQty").text());
                // cartTotal += (parseInt(elm.itemPrice) * qty);
                cartTotal += parseInt(elm.itemPrice);
            }
        });
    });
    $("#totalAmount").text(cartTotal);
    return cartTotal;
}

$(document).on("click",".qtyDec",function(){
    let currentQty = parseInt($(this).siblings(".cartItemQty").text());
    let deleteItem = $(this).closest(".cartItem").attr("id").split("-")[1];
    if(currentQty==1){
        cartItems = jQuery.grep(cartItems, function(value) {
            return value != deleteItem;
        });
        $(this).closest(".cartItem").remove();
        if($(".cartItem").length == 0){
            clearCart();
        }
        localStorage.setItem("pizzaCartItems", JSON.stringify(cartItems));
    }else{
        currentQty = currentQty-1;
        $(this).siblings(".cartItemQty").text(currentQty);
        cartItems.splice( $.inArray(deleteItem,cartItems) ,1 );
        localStorage.setItem("pizzaCartItems", JSON.stringify(cartItems));
    }
    calcTotal();
});

$(document).on("click",".qtyInc",function(){
    let currentQty = parseInt($(this).siblings(".cartItemQty").text());
    let incItem = $(this).closest(".cartItem").attr("id").split("-")[1];
    currentQty = currentQty+1;
    $(this).siblings(".cartItemQty").text(currentQty);
    cartItems.push(incItem);
    localStorage.setItem("pizzaCartItems", JSON.stringify(cartItems));
    calcTotal();
});

$(cartItems).each(function(key, value) {
    checkCart();
    addToCart(value);
    calcTotal();
});

$(document).on("click",".addToCart",function(){
    checkCart();
    let itemId = $(this).closest(".item").attr("id");
    addToCart(itemId);
    calcTotal();
});

$(document).on("click",".checkoutWrapper a",function(){
    alert("Redirecting to Payment Gateway");
    alert("Payment of ₹"+calcTotal()+" Successful! Thanks for visiting!");
    cartItems.length = 0;
    localStorage.setItem("pizzaCartItems", "");
    clearCart();
});

function showItems(){
    dataObj.forEach(elm => {
        $("#"+elm.itemCategory+">.itemsWrapper").append(`
        <div class="item" id="${elm.itemId}">
            <div class="itemTopImage" style="background-image: url(./assets/images/${elm.itemImg});"></div>
            <div class="itemBottomDetail">
                <div class="itemTitle">${elm.itemTitle}</div>
                <div class="itemDescription">${elm.itemDesc}</div>
                <div class="itemBtns">
                    <div class="colLeft">
                        <span class="foodIndicator ${elm.itemType}">•</span>
                        ₹<span class="itemPrice">${elm.itemPrice}</span>
                    </div>
                    <div class="colRight"><a href="javascript:void(0);" class="addToCart">Add</a></div>
                </div>
            </div>
        </div>            
        `);
    });
}

showItems();